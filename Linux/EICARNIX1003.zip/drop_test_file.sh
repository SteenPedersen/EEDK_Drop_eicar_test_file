#!/bin/sh
# Write test eicar to /tmp/eicar.com
# Information about eicar got to www.eicar.org
echo 'K5B!C%@NC[4\CMK54(C^)7PP)7}$RVPNE-FGNAQNEQ-NAGVIVEHF-GRFG-SVYR!$U+U*' | tr '[A-Za-z]' '[N-ZA-Mn-za-m]' > /tmp/eicar.com
#echo test2> /tmp/eicar_test.txt
exit 0
